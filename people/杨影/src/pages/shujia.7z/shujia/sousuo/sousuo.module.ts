import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SousuoPage } from './sousuo';

@NgModule({
  declarations: [
    SousuoPage,
  ],
  imports: [
    IonicPageModule.forChild(SousuoPage),
  ],
})
export class SousuoPageModule {}
