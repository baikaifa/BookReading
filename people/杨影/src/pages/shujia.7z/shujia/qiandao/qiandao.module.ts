import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { QiandaoPage } from './qiandao';

@NgModule({
  declarations: [
    QiandaoPage,
  ],
  imports: [
    IonicPageModule.forChild(QiandaoPage),
  ],
})
export class QiandaoPageModule {}
