import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { XiaoxiPage } from './xiaoxi';

@NgModule({
  declarations: [
    XiaoxiPage,
  ],
  imports: [
    IonicPageModule.forChild(XiaoxiPage),
  ],
})
export class XiaoxiPageModule {}
