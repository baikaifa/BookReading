import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { YueliPage } from './yueli';

@NgModule({
  declarations: [
    YueliPage,
  ],
  imports: [
    IonicPageModule.forChild(YueliPage),
  ],
})
export class YueliPageModule {}
