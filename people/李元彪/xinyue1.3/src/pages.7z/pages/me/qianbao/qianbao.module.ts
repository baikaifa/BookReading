import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { QianbaoPage } from './qianbao';

@NgModule({
  declarations: [
    QianbaoPage,
  ],
  imports: [
    IonicPageModule.forChild(QianbaoPage),
  ],
})
export class QianbaoPageModule {}
